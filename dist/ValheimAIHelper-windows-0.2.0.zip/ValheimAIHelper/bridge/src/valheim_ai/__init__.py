"""Valheim AI local bridge."""

__version__ = "0.2.0"
