"""Valheim AI local bridge."""

__version__ = "0.1.1"
