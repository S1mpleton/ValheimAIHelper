"""Valheim AI local bridge."""
